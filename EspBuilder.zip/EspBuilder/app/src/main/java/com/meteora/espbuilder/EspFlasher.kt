package com.meteora.espbuilder

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume

/** Flasher protokol ROM bootloader ESP (SLIP) lewat USB OTG. Satu image ditulis di offset 0x0. */
class EspFlasher(
    private val ctx: Context,
    private val log: (String) -> Unit,
    private val onProgress: (Float) -> Unit,
) {
    private var port: UsbSerialPort? = null
    private val rx = ArrayDeque<Byte>()
    private val tmp = ByteArray(4096)

    suspend fun flash(image: ByteArray, chip: String, baud: Int) = withContext(Dispatchers.IO) {
        val p = open()
        try {
            log("Masuk mode bootloader...")
            if (!sync()) error("Sync gagal. Tahan BOOT lalu tekan RESET, atau cek kabel OTG.")
            log("Terhubung ke bootloader.")
            val is8266 = chip == "esp8266"
            if (!is8266) {
                cmd(0x0D, i32(0, 0))                                       // SPI attach
                cmd(0x0B, i32(0, 0x1000000, 0x10000, 0x1000, 0x100, 0xFFFF)) // SPI set params
            }
            if (baud != 115200) {
                log("Ubah baud ke $baud")
                cmd(0x0F, i32(baud, 0))
                p.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                Thread.sleep(80)
                purge()
            }
            val block = 0x400
            val blocks = (image.size + block - 1) / block
            val eraseSize = if (is8266) erase8266(0, image.size) else image.size
            log("Menghapus flash (${image.size} byte)...")
            val eraseTimeout = maxOf(3000L, 30000L * eraseSize / (1024 * 1024)) + 5000
            cmd(0x02, i32(eraseSize, blocks, block, 0), 0, eraseTimeout)
            log("Menulis $blocks blok...")
            for (i in 0 until blocks) {
                val chunk = ByteArray(block) { 0xFF.toByte() }
                val from = i * block
                System.arraycopy(image, from, chunk, 0, minOf(block, image.size - from))
                var chk = 0xEF
                for (b in chunk) chk = chk xor (b.toInt() and 0xFF)
                cmd(0x03, i32(block, i, 0, 0) + chunk, chk, 5000)
                onProgress((i + 1).toFloat() / blocks)
            }
            runCatching { cmd(0x04, i32(1)) }
            hardReset()
            log("Selesai. Perangkat di-reset.")
        } finally {
            runCatching { p.close() }
        }
    }

    // ---------- USB ----------
    private suspend fun open(): UsbSerialPort {
        val mgr = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(mgr).firstOrNull()
            ?: error("Perangkat USB serial tidak ditemukan. Cek kabel OTG.")
        if (!mgr.hasPermission(driver.device) && !askPermission(mgr, driver.device)) error("Izin USB ditolak")
        val conn = mgr.openDevice(driver.device) ?: error("Gagal membuka perangkat USB")
        val p = driver.ports[0]
        p.open(conn)
        p.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        port = p
        return p
    }

    private suspend fun askPermission(mgr: UsbManager, dev: UsbDevice): Boolean =
        suspendCancellableCoroutine { cont ->
            val action = "${ctx.packageName}.USB_PERMISSION"
            val rcv = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    ctx.unregisterReceiver(this)
                    if (cont.isActive) cont.resume(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
            ContextCompat.registerReceiver(ctx, rcv, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(ctx, 0, Intent(action).setPackage(ctx.packageName), flags)
            mgr.requestPermission(dev, pi)
        }

    // ---------- reset ----------
    private fun resetToBootloader() {
        val p = port!!
        p.setDTR(false); p.setRTS(true)
        Thread.sleep(100)
        p.setDTR(true); p.setRTS(false)
        Thread.sleep(50)
        p.setDTR(false)
    }

    private fun hardReset() {
        val p = port!!
        p.setDTR(false); p.setRTS(true)
        Thread.sleep(100)
        p.setRTS(false)
    }

    // ---------- protokol ----------
    private fun sync(): Boolean {
        val d = ByteArray(36) { 0x55 }
        d[0] = 7; d[1] = 7; d[2] = 0x12; d[3] = 0x20
        repeat(6) {
            runCatching { resetToBootloader() }
            purge()
            repeat(5) {
                write(frame(0x08, d, 0))
                val end = System.currentTimeMillis() + 150
                while (System.currentTimeMillis() < end) {
                    val f = readFrame(end - System.currentTimeMillis()) ?: break
                    if (f.size >= 8 && f[0] == 1.toByte() && f[1] == 8.toByte()) {
                        Thread.sleep(100)
                        purge()
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun cmd(op: Int, data: ByteArray, chk: Int = 0, timeout: Long = 3000): ByteArray {
        write(frame(op, data, chk))
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            val f = readFrame(end - System.currentTimeMillis()) ?: break
            if (f.size < 10 || f[0] != 1.toByte() || (f[1].toInt() and 0xFF) != op) continue
            if (f[8].toInt() != 0) {
                throw RuntimeException("Perintah 0x%02X gagal (kode 0x%02X)".format(op, f[9].toInt() and 0xFF))
            }
            return f
        }
        throw RuntimeException("Timeout menunggu respons perintah 0x%02X".format(op))
    }

    private fun frame(op: Int, data: ByteArray, chk: Int): ByteArray {
        val b = ByteBuffer.allocate(8 + data.size).order(ByteOrder.LITTLE_ENDIAN)
        b.put(0.toByte()).put(op.toByte()).putShort(data.size.toShort()).putInt(chk).put(data)
        return slip(b.array())
    }

    private fun slip(src: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0xC0)
        for (x in src) {
            when (x.toInt() and 0xFF) {
                0xC0 -> { o.write(0xDB); o.write(0xDC) }
                0xDB -> { o.write(0xDB); o.write(0xDD) }
                else -> o.write(x.toInt())
            }
        }
        o.write(0xC0)
        return o.toByteArray()
    }

    private fun i32(vararg v: Int): ByteArray {
        val b = ByteBuffer.allocate(4 * v.size).order(ByteOrder.LITTLE_ENDIAN)
        v.forEach { b.putInt(it) }
        return b.array()
    }

    private fun write(data: ByteArray) = port!!.write(data, 5000)

    private fun readByte(deadline: Long): Int {
        while (rx.isEmpty()) {
            val rem = deadline - System.currentTimeMillis()
            if (rem <= 0) return -1
            val n = port!!.read(tmp, minOf(rem, 100L).toInt())
            for (i in 0 until n) rx.addLast(tmp[i])
        }
        return rx.removeFirst().toInt() and 0xFF
    }

    private fun readFrame(timeoutMs: Long): ByteArray? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val b = readByte(deadline)
            if (b < 0) return null
            if (b == 0xC0) break
        }
        val o = ByteArrayOutputStream()
        while (true) {
            var b = readByte(deadline)
            if (b < 0) return null
            if (b == 0xC0) {
                if (o.size() == 0) continue
                return o.toByteArray()
            }
            if (b == 0xDB) {
                val c = readByte(deadline)
                if (c < 0) return null
                b = when (c) { 0xDC -> 0xC0; 0xDD -> 0xDB; else -> c }
            }
            o.write(b)
        }
    }

    private fun purge() {
        rx.clear()
        runCatching { port?.purgeHwBuffers(true, true) }
        while (runCatching { port!!.read(tmp, 20) }.getOrDefault(0) > 0) { /* kuras */ }
    }

    private fun erase8266(offset: Int, size: Int): Int {
        val sector = 4096
        val perBlock = 16
        val numSectors = (size + sector - 1) / sector
        val start = offset / sector
        var head = perBlock - (start % perBlock)
        if (numSectors < head) head = numSectors
        return if (numSectors < 2 * head) (numSectors + 1) / 2 * sector else (numSectors - head) * sector
    }
}
