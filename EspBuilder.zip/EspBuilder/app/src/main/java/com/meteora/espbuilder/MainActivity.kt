package com.meteora.espbuilder

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

class Store(ctx: Context) {
    private val plain = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val secure = EncryptedSharedPreferences.create(
        ctx, "secure_cfg",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    var token: String
        get() = secure.getString("token", "") ?: ""
        set(v) { secure.edit().putString("token", v).apply() }

    fun get(k: String, d: String) = plain.getString(k, d) ?: d
    fun put(k: String, v: String) = plain.edit().putString(k, v).apply()
}

@Composable
fun Choice(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(label, style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        options.forEach { o ->
            Row(
                Modifier.clickable { onSelect(o) }.padding(end = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = o == selected, onClick = { onSelect(o) })
                Text(o)
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()

    var token by remember { mutableStateOf(store.token) }
    var repo by remember { mutableStateOf(store.get("repo", "")) }
    var branch by remember { mutableStateOf(store.get("branch", "main")) }
    var wf by remember { mutableStateOf(store.get("wf", "build-firmware.yml")) }
    var env by remember { mutableStateOf(store.get("env", "")) }
    var chip by remember { mutableStateOf(store.get("chip", "esp32")) }
    var baud by remember { mutableStateOf(store.get("baud", "460800")) }

    var logText by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var fw by remember { mutableStateOf<ByteArray?>(null) }
    var fwName by remember { mutableStateOf("") }

    val log: (String) -> Unit = { s -> scope.launch(Dispatchers.Main) { logText += s + "\n" } }

    fun job(block: suspend () -> Unit) {
        scope.launch {
            busy = true; progress = 0f
            try { block() } catch (e: Exception) { log("Error: ${e.message}") } finally { busy = false }
        }
    }

    suspend fun setup() = withContext(Dispatchers.IO) {
        val yml = ctx.assets.open("build-firmware.yml").bufferedReader().readText()
        GitHub(token.trim()).putFile(repo.trim(), ".github/workflows/$wf", yml, "Add firmware build workflow", branch.trim())
        log("Workflow terpasang di $repo ($wf)")
    }

    suspend fun build() = withContext(Dispatchers.IO) {
        val gh = GitHub(token.trim())
        val r = repo.trim(); val b = branch.trim()
        val prev = gh.latestRun(r, wf, b)?.first
        log("Memicu workflow...")
        gh.dispatch(r, wf, b, mapOf("pio_env" to env.trim(), "chip" to chip))
        var runId: Long? = null
        for (i in 0 until 30) {
            delay(2000)
            val l = gh.latestRun(r, wf, b)
            if (l != null && l.first != prev) { runId = l.first; break }
        }
        val id = runId ?: error("Run baru tidak muncul. Cek nama workflow dan branch.")
        log("Run #$id berjalan...")
        var last = ""
        while (true) {
            delay(5000)
            val run = gh.run(r, id)
            val st = run.getString("status")
            if (st != last) { log("Status: $st"); last = st }
            if (st == "completed") {
                val c = run.optString("conclusion")
                if (c != "success") error("Build $c. Lihat tab Actions di GitHub.")
                break
            }
        }
        val art = gh.firstArtifact(r, id) ?: error("Artifact tidak ditemukan")
        val dir = File(ctx.cacheDir, "fw").apply { deleteRecursively(); mkdirs() }
        val bin = gh.downloadArtifact(r, art, dir).firstOrNull { it.extension == "bin" }
            ?: error("Tidak ada file .bin di artifact")
        val bytes = bin.readBytes()
        withContext(Dispatchers.Main) { fw = bytes; fwName = bin.name }
        log("Selesai: ${bin.name} (${bytes.size} byte)")
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) job {
            val bytes = withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            }
            fw = bytes; fwName = uri.lastPathSegment ?: "file.bin"
            log("Dimuat: $fwName (${bytes.size} byte)")
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("ESP Builder", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(token, { token = it; store.token = it }, label = { Text("GitHub token") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(repo, { repo = it; store.put("repo", it) }, label = { Text("Repo (owner/nama)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(branch, { branch = it; store.put("branch", it) }, label = { Text("Branch") },
                singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(env, { env = it; store.put("env", it) }, label = { Text("PIO env") },
                singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(wf, { wf = it; store.put("wf", it) }, label = { Text("File workflow") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Choice("Chip", listOf("esp32", "esp32s2", "esp32s3", "esp32c3", "esp8266"), chip) { chip = it; store.put("chip", it) }
        Choice("Baud flash", listOf("115200", "460800", "921600"), baud) { baud = it; store.put("baud", it) }

        OutlinedButton({ job { setup() } }, enabled = !busy && token.isNotBlank() && repo.isNotBlank(),
            modifier = Modifier.fillMaxWidth()) { Text("Pasang workflow ke repo") }
        Button({ job { build() } }, enabled = !busy && token.isNotBlank() && repo.isNotBlank() && env.isNotBlank(),
            modifier = Modifier.fillMaxWidth()) { Text("Build di GitHub") }
        OutlinedButton({ picker.launch("*/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Pilih .bin dari HP")
        }
        Button(
            { job { EspFlasher(ctx, log) { progress = it }.flash(fw!!, chip, baud.toInt()) } },
            enabled = !busy && fw != null, modifier = Modifier.fillMaxWidth(),
        ) { Text(if (fw == null) "Flash via USB OTG" else "Flash $fwName via USB OTG") }

        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        Text(logText, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    }
}
