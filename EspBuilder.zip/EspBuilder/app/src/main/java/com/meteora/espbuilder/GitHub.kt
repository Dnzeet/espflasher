package com.meteora.espbuilder

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class GitHub(private val token: String) {
    private val client = OkHttpClient.Builder()
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val json = "application/json".toMediaType()
    private val api = "https://api.github.com"

    private fun req(url: String) = Request.Builder().url(url)
        .header("Authorization", "Bearer $token")
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")

    private fun call(r: Request): String = client.newCall(r).execute().use {
        val body = it.body?.string().orEmpty()
        if (!it.isSuccessful) {
            val msg = runCatching { JSONObject(body).optString("message", body) }.getOrDefault(body)
            throw RuntimeException("GitHub ${it.code}: $msg")
        }
        body
    }

    fun dispatch(repo: String, workflow: String, ref: String, inputs: Map<String, String>) {
        val j = JSONObject().put("ref", ref).put("inputs", JSONObject(inputs))
        call(
            req("$api/repos/$repo/actions/workflows/$workflow/dispatches")
                .post(j.toString().toRequestBody(json)).build()
        )
    }

    /** Run workflow_dispatch terbaru: (id, objek run) */
    fun latestRun(repo: String, workflow: String, ref: String): Pair<Long, JSONObject>? {
        val s = call(
            req("$api/repos/$repo/actions/workflows/$workflow/runs?per_page=1&event=workflow_dispatch&branch=$ref").build()
        )
        val arr = JSONObject(s).getJSONArray("workflow_runs")
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return o.getLong("id") to o
    }

    fun run(repo: String, id: Long): JSONObject =
        JSONObject(call(req("$api/repos/$repo/actions/runs/$id").build()))

    fun firstArtifact(repo: String, runId: Long): Long? {
        val arr = JSONObject(call(req("$api/repos/$repo/actions/runs/$runId/artifacts").build()))
            .getJSONArray("artifacts")
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (!a.optBoolean("expired")) return a.getLong("id")
        }
        return null
    }

    fun downloadArtifact(repo: String, id: Long, dir: File): List<File> {
        val out = mutableListOf<File>()
        client.newCall(req("$api/repos/$repo/actions/artifacts/$id/zip").build()).execute().use { resp ->
            if (!resp.isSuccessful) throw RuntimeException("Unduh gagal: ${resp.code}")
            ZipInputStream(resp.body!!.byteStream()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    val f = File(dir, File(e.name).name)
                    f.outputStream().use { z.copyTo(it) }
                    out += f
                }
            }
        }
        return out
    }

    fun putFile(repo: String, path: String, content: String, message: String, branch: String) {
        val url = "$api/repos/$repo/contents/$path"
        val sha = runCatching {
            JSONObject(call(req("$url?ref=$branch").build())).getString("sha")
        }.getOrNull()
        val j = JSONObject()
            .put("message", message)
            .put("branch", branch)
            .put("content", Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP))
        if (sha != null) j.put("sha", sha)
        call(req(url).put(j.toString().toRequestBody(json)).build())
    }
}
